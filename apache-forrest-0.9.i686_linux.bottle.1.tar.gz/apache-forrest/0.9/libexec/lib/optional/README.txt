Place jars that you want included in Forrest here.
An example is that of the Jimi jar, to have images rendered in PDFs.
http://forrest.apache.org/faq.html#pdf_images
