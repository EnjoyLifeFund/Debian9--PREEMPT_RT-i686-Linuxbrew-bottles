module Asciidoctor
  VERSION = '1.5.6.2'
end
