class Regexp
  alias match? === unless method_defined? :match?
end
