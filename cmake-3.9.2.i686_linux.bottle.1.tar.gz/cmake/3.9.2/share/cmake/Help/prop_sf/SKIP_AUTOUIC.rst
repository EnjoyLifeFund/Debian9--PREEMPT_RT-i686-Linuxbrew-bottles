SKIP_AUTOUIC
------------

Exclude the source file from :prop_tgt:`AUTOUIC` processing (for Qt projects).

For broader control see :prop_sf:`SKIP_AUTOGEN`
