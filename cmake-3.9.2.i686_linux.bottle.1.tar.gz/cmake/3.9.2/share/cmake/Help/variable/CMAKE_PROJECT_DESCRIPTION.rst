CMAKE_PROJECT_DESCRIPTION
-------------------------

The description of the current project.

This specifies description of the current project from the closest inherited
:command:`project` command.
