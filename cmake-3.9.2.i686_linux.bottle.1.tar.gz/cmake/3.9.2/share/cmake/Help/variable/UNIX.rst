UNIX
----

``True`` for UNIX and UNIX like operating systems.

Set to ``true`` when the target system is UNIX or UNIX like (i.e.
:variable:`APPLE` and :variable:`CYGWIN`).
