CMAKE_<LANG>_FLAGS_DEBUG
------------------------

Flags for ``Debug`` build type or configuration.

``<LANG>`` flags used when :variable:`CMAKE_BUILD_TYPE` is ``Debug``.
