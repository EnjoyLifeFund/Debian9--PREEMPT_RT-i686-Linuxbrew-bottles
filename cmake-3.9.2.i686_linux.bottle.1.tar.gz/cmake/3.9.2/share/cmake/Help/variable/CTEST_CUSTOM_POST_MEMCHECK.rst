CTEST_CUSTOM_POST_MEMCHECK
--------------------------

A list of commands to run at the end of the :command:`ctest_memcheck` command.

.. include:: CTEST_CUSTOM_XXX.txt
