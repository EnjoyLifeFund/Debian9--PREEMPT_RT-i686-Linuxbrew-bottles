CTEST_TRIGGER_SITE
------------------

Specify the CTest ``TriggerSite`` setting
in a :manual:`ctest(1)` dashboard client script.
