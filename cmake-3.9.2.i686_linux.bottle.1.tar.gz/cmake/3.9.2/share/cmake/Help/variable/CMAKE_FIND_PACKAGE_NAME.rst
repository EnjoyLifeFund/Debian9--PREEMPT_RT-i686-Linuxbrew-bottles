CMAKE_FIND_PACKAGE_NAME
-----------------------

Defined by the :command:`find_package` command while loading
a find module to record the caller-specified package name.
See command documentation for details.
