WINCE
-----

True when the :variable:`CMAKE_SYSTEM_NAME` variable is set
to ``WindowsCE``.
