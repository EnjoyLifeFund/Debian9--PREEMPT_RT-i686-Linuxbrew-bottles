CMAKE_CROSSCOMPILING
--------------------

Is CMake currently cross compiling.

This variable will be set to true by CMake if CMake is cross
compiling.  Specifically if the build platform is different from the
target platform.
