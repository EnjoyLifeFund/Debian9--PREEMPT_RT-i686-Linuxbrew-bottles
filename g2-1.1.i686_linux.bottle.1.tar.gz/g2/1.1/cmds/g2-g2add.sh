#!/bin/bash
#
source "$G2_HOME/cmds/color.sh"
fatal "Please don't use ${boldon}add${boldoff} with G2, ${boldon}freeze${boldoff} and ${boldon}unfreeze${boldoff} are more powerfull commands"