.. cmake-module:: ../../Modules/FindPike.cmake
