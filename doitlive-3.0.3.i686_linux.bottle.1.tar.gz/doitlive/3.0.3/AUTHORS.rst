*******
Authors
*******

Lead
====

- Steven Loria `@sloria <https://github.com/sloria>`_

Contributors (chronological)
============================

- Josh Carp `@jmcarp <http://github.com/jmcarp>`_
- Austin Macdonald `@asmacdo <http://github.com/asmacdo>`_
- Jordi Hermoso `@jordigh <https://github.com/jordigh>`_
- Stefan-Code `@Stefan-Code <https://github.com/Stefan-Code>`_
- André Felipe Dias  `@andredias <https://github.com/andredias>`_
- @axocomm `@axocomm <https://github.com/axocomm>`_
- Thomas Ashish Cherian `@PandaWhoCodes <https://github.com/PandaWhoCodes>`_
