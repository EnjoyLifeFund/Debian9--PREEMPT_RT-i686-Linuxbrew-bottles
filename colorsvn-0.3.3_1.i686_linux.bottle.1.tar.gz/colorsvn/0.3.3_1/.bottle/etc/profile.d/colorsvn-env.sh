# set alias for svn

alias svn=@@HOMEBREW_REPOSITORY@@/Cellar/colorsvn/0.3.3_1/bin/colorsvn
