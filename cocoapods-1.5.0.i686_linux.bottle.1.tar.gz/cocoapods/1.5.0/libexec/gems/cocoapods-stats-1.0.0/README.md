# cocoapods-stats

Collects and sends simple analytics data to the [stats.cocoapods.org](https://stats.cocoapods.org) back-end.

## Installation

    $ gem install cocoapods-stats

## Usage

    $ pod spec stats POD_NAME
