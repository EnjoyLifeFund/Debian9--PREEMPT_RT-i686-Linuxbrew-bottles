require 'cocoapods/deintegrate/gem_version'
require 'cocoapods/deintegrator'
