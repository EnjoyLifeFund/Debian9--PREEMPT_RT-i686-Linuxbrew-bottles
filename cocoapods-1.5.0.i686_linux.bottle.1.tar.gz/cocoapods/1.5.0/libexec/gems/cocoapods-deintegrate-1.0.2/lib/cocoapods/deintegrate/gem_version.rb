module CocoapodsDeintegrate
  VERSION = '1.0.2'.freeze
end
