module Fourflusher
  VERSION = '2.0.1'
end
