### Master

### 1.1.3

* Require IRB early in the lib's lifecycle - segiddins

### 1.1.2

* URL escape the query for GH issues - revolter

### 1.1.1

* Allow either all typoes, or all no typoes in the delegate call - revolter

### 1.1.0

* Fixes typos in the delegate methods - revolter
* Adds support for showing how to click on a link in terminal - 0xced

### 1.0.3

* Fixes for URLs with spaces - orta

### 1.0.0

* Initial major release - orta + krausefx 
