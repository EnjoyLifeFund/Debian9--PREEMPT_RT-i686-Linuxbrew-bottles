module GhInspector
  VERSION = '1.1.3'.freeze
end
