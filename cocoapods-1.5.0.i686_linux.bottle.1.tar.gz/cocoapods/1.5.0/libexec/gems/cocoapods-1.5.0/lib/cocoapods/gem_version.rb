module Pod
  # The version of the CocoaPods command line tool.
  #
  VERSION = '1.5.0'.freeze unless defined? Pod::VERSION
end
