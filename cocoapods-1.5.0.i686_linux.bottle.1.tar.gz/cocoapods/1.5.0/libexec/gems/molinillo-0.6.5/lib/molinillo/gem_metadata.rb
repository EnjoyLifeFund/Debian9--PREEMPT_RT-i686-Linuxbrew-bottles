# frozen_string_literal: true

module Molinillo
  # The version of Molinillo.
  VERSION = '0.6.5'.freeze
end
