module Concurrent
  VERSION      = '1.0.5'
  EDGE_VERSION = '0.3.1'
end
