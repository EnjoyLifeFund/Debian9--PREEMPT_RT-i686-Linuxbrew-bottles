module Pod
  module Downloader
    # @return [String] Downloader’s version, following
    #         [semver](http://semver.org).
    #
    VERSION = '1.2.0'.freeze
  end
end
