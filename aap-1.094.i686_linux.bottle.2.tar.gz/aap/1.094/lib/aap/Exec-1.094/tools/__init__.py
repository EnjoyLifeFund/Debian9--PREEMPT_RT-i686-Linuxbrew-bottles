# Part of the A-A-P recipe executive: Tools package

# Copyright (c) 2002-2003 stichting NLnet Labs
# Permission to copy and use this file is specified in the file COPYING.
# If this file is missing you can find it here: http://www.a-a-p.org/COPYING

#
# This doesn't do anything, only marks the modules in this directory as
# belonging to the "tools" package.
#


# vim: set sw=4 et sts=4 tw=79 fo+=l:
