#! /usr/bin/env python
# Part of the A-A-P recipe executive: The main program.

# Copyright (C) 2002-2003 Stichting NLnet Labs
# Permission to copy and use this file is specified in the file COPYING.
# If this file is missing you can find it here: http://www.a-a-p.org/COPYING

# This simply calls the main() function in the Main.py module.

import Main

if __name__ == '__main__':
    Main.main(1)

# vim: set sw=4 et sts=4 tw=79 fo+=l:
