#! /usr/bin/env python
# Part of the A-A-P recipe executive: Print a profile

# Copyright (C) 2002-2003 Stichting NLnet Labs
# Permission to copy and use this file is specified in the file COPYING.
# If this file is missing you can find it here: http://www.a-a-p.org/COPYING

import sys
import pstats

if __name__ == '__main__':
    p = pstats.Stats(sys.argv[1])
    p.sort_stats('time')
    p.print_stats()
    p.sort_stats('cumulative')
    p.print_stats()
    p.sort_stats('time')
    p.print_callers()
    p.sort_stats('cumulative')
    p.print_callees()


# vim: set sw=4 et sts=4 tw=79 fo+=l:
